import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./NavBar";
import Footer from "./Footer";
import Home from "./Home";
import About from "./About";
import Install from "./Install";
import Login from "./Login";
import Docs from "./Docs";
import Pagenotfound from "./Pagenotfound";

export default function App() {
  return (
    <Router>
      {/* Navbar appears on every page */}
      <Navbar />

      {/* Routes */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/Install" element={<Install />} />
        <Route path="/docs" element={<Docs />} />
        <Route path="/login" element={<Login />} />
        <Route path="/*" element={<Pagenotfound />} />
      </Routes>

      {/* Footer appears on every page */}
      <Footer />
    </Router>
  );
}

