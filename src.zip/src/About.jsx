import React from "react";
import { Briefcase, Code2, Target, User } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-black text-white px-6 sm:px-16 py-20 flex flex-col items-center">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="text-5xl font-extrabold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
          About Me 👨‍💻
        </h1>
        <p className="text-gray-300 max-w-2xl mx-auto text-lg">
            <h1>✨M TALHA ILYAS✨</h1>
          Passionate React developer with a strong background in programming, design, and AI.
          I love building modern, scalable web experiences that merge creativity with technology.
        </p>
      </div>

      {/* Content */}
      <div className="grid md:grid-cols-2 gap-10 w-full max-w-6xl">
        {/* Left: My Journey */}
        <div className="bg-white/5 p-8 rounded-2xl border border-white/10 shadow-xl backdrop-blur-md hover:bg-white/10 transition">
          <div className="flex items-center space-x-3 mb-5">
            <User className="w-8 h-8 text-blue-400" />
            <h2 className="text-2xl font-bold text-blue-300">My Background</h2>
          </div>
          <p className="text-gray-400 leading-relaxed">
            I started my coding journey with <span className="text-blue-400 font-medium">Python</span> and later mastered 
            <span className="text-blue-400 font-medium"> React.js</span> and 
            <span className="text-blue-400 font-medium"> Tailwind CSS</span>.
            My passion for technology led me into <span className="text-blue-400 font-medium">Machine Learning</span> and 
            <span className="text-blue-400 font-medium"> AI development</span>.  
            Over time, I have built dynamic interfaces, responsive dashboards, and smart AI-powered web apps.
          </p>
        </div>

        {/* Right: My Mission */}
        <div className="bg-white/5 p-8 rounded-2xl border border-white/10 shadow-xl backdrop-blur-md hover:bg-white/10 transition">
          <div className="flex items-center space-x-3 mb-5">
            <Target className="w-8 h-8 text-cyan-400" />
            <h2 className="text-2xl font-bold text-cyan-300">My Mission</h2>
          </div>
          <p className="text-gray-400 leading-relaxed">
            My mission is to create meaningful digital experiences that make technology more accessible and enjoyable.
            I believe in combining <span className="text-cyan-400 font-medium">aesthetic design</span> with 
            <span className="text-cyan-400 font-medium"> functional excellence</span> to build interfaces that people love to use.  
            Every project is a step toward mastering full-stack innovation and AI-powered solutions.
          </p>
        </div>
      </div>

      {/* Skills Section */}
      <div className="mt-20 max-w-6xl w-full text-center">
        <h2 className="text-3xl font-bold text-blue-300 mb-10">My Expertise</h2>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          <div className="bg-white/10 rounded-2xl p-6 hover:bg-white/20 transition shadow-lg">
            <Code2 className="w-10 h-10 mx-auto text-blue-400 mb-4" />
            <h3 className="font-semibold text-lg">Frontend Development</h3>
            <p className="text-gray-400 text-sm mt-2">
              React.js, Tailwind CSS, Next.js, Vite
            </p>
          </div>
          <div className="bg-white/10 rounded-2xl p-6 hover:bg-white/20 transition shadow-lg">
            <Briefcase className="w-10 h-10 mx-auto text-cyan-400 mb-4" />
            <h3 className="font-semibold text-lg">Backend & APIs</h3>
            <p className="text-gray-400 text-sm mt-2">
              Node.js, Express.js, Flask, FastAPI
            </p>
          </div>
          <div className="bg-white/10 rounded-2xl p-6 hover:bg-white/20 transition shadow-lg">
            <Target className="w-10 h-10 mx-auto text-indigo-400 mb-4" />
            <h3 className="font-semibold text-lg">Machine Learning</h3>
            <p className="text-gray-400 text-sm mt-2">
              Python, NumPy, scikit-learn, TensorFlow
            </p>
          </div>
          <div className="bg-white/10 rounded-2xl p-6 hover:bg-white/20 transition shadow-lg">
            <h3 className="font-semibold text-lg">Freelancing</h3>
            <p className="text-gray-400 text-sm mt-2">
              Building AI + Web solutions for global clients.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
