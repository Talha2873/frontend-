import React from "react";

export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center relative overflow-hidden bg-gradient-to-br from-gray-950 via-blue-950 to-black text-white px-6">
      {/* Background Glow / Overlay */}
      <div className="absolute inset-0">
        <div className="absolute top-1/3 left-1/4 w-96 h-96 bg-blue-600/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse delay-2000"></div>
        <div className="bg-center absolute inset-0 bg-[url('Talha.png')] opacity-10"></div>
      </div>

      {/* Hero Section */}
      <main className="relative z-10 flex flex-col items-center justify-center py-32">
        {/* Logo */}
        <div className="relative mb-8">
          <div className="absolute inset-0 blur-3xl bg-blue-500/40 rounded-full w-32 h-32 mx-auto animate-pulse"></div>
          <img
            src="https://upload.wikimedia.org/wikipedia/commons/a/a7/React-icon.svg"
            alt="React Logo"
            className="w-28 h-28 relative z-10 drop-shadow-2xl animate-spin-slow"
          />
        </div>

        {/* Headline */}
        <h1 className="text-5xl sm:text-6xl font-extrabold mb-4 leading-tight tracking-tight">
          Build the Future with{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
            React & Tailwind
          </span>
        </h1>

        {/* Subtext */}
        <p className="text-gray-300 max-w-2xl text-lg mb-10">
          Empower your creativity and build fast, responsive, and stunning web
          applications using{" "}
          <span className="text-blue-400 font-semibold">
            modern frontend technologies.
          </span>
        </p>

        {/* CTA Button */}
        <button className="relative px-10 py-4 rounded-full font-bold text-lg bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 hover:scale-105 transition-transform shadow-xl">
          Get Started 🚀
          <span className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-400 blur-md opacity-50 rounded-full -z-10"></span>
        </button>
      </main>
    </div>
  );
}
