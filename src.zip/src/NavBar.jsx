import React from "react";
import { Link, useLocation } from "react-router-dom";

export default function Navbar() {
  const location = useLocation();

  return (
    <nav className="w-screen fixed top-0 left-0 w-full z-50 backdrop-blur-md bg-white/5 border-b border-white/10 flex items-center justify-between px-10 py-4 shadow-lg">
      {/* Left Nav Links */}
      <ul className="flex space-x-10 font-semibold tracking-wide">
        {[
          { name: "Home", path: "/" },
          { name: "About", path: "/about" },
          { name: "Docs", path: "/docs" },
          { name: "Install", path: "/Install" },
        ].map((link) => (
          <li key={link.path}>
            <Link
              to={link.path}
              className={`transition ${
                location.pathname === link.path
                  ? "text-blue-400"
                  : "hover:text-blue-400"
              }`}
            >
              {link.name}
            </Link>
          </li>
        ))}
      </ul>

      {/* Right Button */}
      <Link
        to="/login"
        className="bg-gradient-to-r from-blue-500 to-cyan-400 hover:from-blue-600 hover:to-cyan-500 text-white font-semibold px-6 py-2 rounded-full shadow-md transition duration-300"
      >
        Log In
      </Link>
    </nav>
  );
}
