import React from "react";
import { Terminal, Code, Zap } from "lucide-react";

export default function Install() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 text-white px-6 py-20">
      {/* Hero Section */}
      <div className="text-center mb-16">
        <h1 className="text-5xl font-extrabold mb-4 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
          Installation Guide 🚀
        </h1>
        <p className="text-gray-400 text-lg max-w-2xl mx-auto">
          Follow these simple steps to set up your React + Tailwind project
          in minutes and start building powerful, beautiful UIs.
        </p>
      </div>

      {/* Installation Steps */}
      <div className="grid md:grid-cols-3 gap-10 max-w-6xl mx-auto">
        {/* Step 1 */}
        <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700 rounded-2xl p-8 shadow-lg hover:shadow-blue-400/30 transition-all hover:scale-[1.03]">
          <div className="flex items-center gap-3 mb-4">
            <Terminal className="text-blue-400 w-6 h-6" />
            <h2 className="text-2xl font-semibold">Step 1: Create React App</h2>
          </div>
          <p className="text-gray-300 mb-4">
            Start a new Vite + React project with the following command:
          </p>
          <pre className="bg-black/40 text-green-400 p-4 rounded-xl text-sm overflow-x-auto border border-gray-700">
            npm create vite@latest my-project -- --template react
            <br />
            cd my-project
            <br />
            npm install
          </pre>
        </div>

        {/* Step 2 */}
        <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700 rounded-2xl p-8 shadow-lg hover:shadow-blue-400/30 transition-all hover:scale-[1.03]">
          <div className="flex items-center gap-3 mb-4">
            <Code className="text-blue-400 w-6 h-6" />
            <h2 className="text-2xl font-semibold">Step 2: Add Tailwind CSS</h2>
          </div>
          <p className="text-gray-300 mb-4">
            Set up Tailwind by running these commands:
          </p>
          <pre className="bg-black/40 text-green-400 p-4 rounded-xl text-sm overflow-x-auto border border-gray-700">
            npm install -D tailwindcss postcss autoprefixer
            <br />
            npx tailwindcss init -p
          </pre>
          <p className="text-gray-400 mt-3">
            Then update <code>tailwind.config.js</code> and your CSS files.
          </p>
        </div>

        {/* Step 3 */}
        <div className="bg-gray-800/60 backdrop-blur-xl border border-gray-700 rounded-2xl p-8 shadow-lg hover:shadow-blue-400/30 transition-all hover:scale-[1.03]">
          <div className="flex items-center gap-3 mb-4">
            <Zap className="text-blue-400 w-6 h-6" />
            <h2 className="text-2xl font-semibold">Step 3: Run the App</h2>
          </div>
          <p className="text-gray-300 mb-4">
            Start your development server to see your app live:
          </p>
          <pre className="bg-black/40 text-green-400 p-4 rounded-xl text-sm overflow-x-auto border border-gray-700">
            npm run dev
          </pre>
          <p className="text-gray-400 mt-3">
            Open the URL shown in your terminal — usually{" "}
            <code>http://localhost:5173</code>.
          </p>
        </div>
      </div>

      {/* Footer Note */}
      <div className="text-center mt-16 text-gray-500 text-sm">
        ⚙️ Need help? Visit{" "}
        <a
          href="https://tailwindcss.com/docs/installation"
          target="_blank"
          rel="noopener noreferrer"
          className="text-blue-400 hover:underline"
        >
          Tailwind Docs
        </a>{" "}
        or{" "}
        <a
          href="https://vitejs.dev/guide/"
          target="_blank"
          rel="noopener noreferrer"
          className="text-cyan-400 hover:underline"
        >
          Vite Guide
        </a>
        .
      </div>
    </div>
  );
}
