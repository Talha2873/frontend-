import { Link } from "react-router-dom";
import NavBar from "./NavBar";
import Footer from "./Footer";

export default function Docs() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-black text-white font-sans flex flex-col">
      {/* ✅ Fixed Navbar Component */}
      <NavBar />

      {/* ✅ Page Content - padded to avoid overlap */}
      <main className="flex-grow pt-32 pb-28 px-6 sm:px-16 lg:px-32 text-center overflow-auto">
        {/* Header Section */}
        <h1 className="text-5xl sm:text-6xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
          Developer Docs
        </h1>
        <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-12">
          Explore in-depth articles, guides, and tutorials on modern web development —  
          from mastering React fundamentals to harnessing the beauty of Tailwind CSS.
        </p>

        {/* Docs Cards */}
        <div className="grid md:grid-cols-2 gap-12 mt-8">
          {/* React Card */}
          <div className="relative group bg-white/5 border border-white/10 rounded-2xl p-8 text-left hover:bg-white/10 transition duration-500 backdrop-blur-lg shadow-lg">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-500/30 to-cyan-500/30 opacity-0 group-hover:opacity-100 blur-xl transition duration-700"></div>
            <h2 className="text-3xl font-bold mb-4 text-blue-400">⚛️ Mastering React</h2>
            <p className="text-gray-300 leading-relaxed mb-4">
              React is a powerful JavaScript library for building user interfaces. 
              It promotes reusable components, state management with Hooks, 
              and high performance through the Virtual DOM.
            </p>
            <ul className="list-disc list-inside text-gray-400 mb-6">
              <li>Understand JSX and Virtual DOM</li>
              <li>Reusable functional components</li>
              <li>State management with Hooks</li>
              <li>Global state via Context API</li>
            </ul>
            <button className="bg-gradient-to-r from-blue-600 to-cyan-500 hover:from-blue-700 hover:to-cyan-600 px-5 py-2 rounded-full font-semibold transition duration-300 shadow-lg">
              Read More →
            </button>
          </div>

          {/* Tailwind Card */}
          <div className="relative group bg-white/5 border border-white/10 rounded-2xl p-8 text-left hover:bg-white/10 transition duration-500 backdrop-blur-lg shadow-lg">
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/30 to-purple-500/30 opacity-0 group-hover:opacity-100 blur-xl transition duration-700"></div>
            <h2 className="text-3xl font-bold mb-4 text-cyan-400">🎨 Styling with Tailwind CSS</h2>
            <p className="text-gray-300 leading-relaxed mb-4">
              Tailwind CSS is a utility-first framework for building beautiful, responsive UIs 
              directly in your markup — perfect for React projects.
            </p>
            <ul className="list-disc list-inside text-gray-400 mb-6">
              <li>Responsive utility classes</li>
              <li>Dark mode integration</li>
              <li>Custom gradients & animations</li>
              <li>Seamless React compatibility</li>
            </ul>
            <button className="bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 px-5 py-2 rounded-full font-semibold transition duration-300 shadow-lg">
              Read More →
            </button>
          </div>
        </div>
      </main>

      {/* ✅ Footer Component */}
      <Footer />
    </div>
  );
}
