import React from "react";
import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="w-screen bg-gradient-to-r from-slate-950 via-blue-950 to-slate-950 text-gray-300 py-10 border-t border-white/10 mt-16">
      <div className="container mx-auto px-6 text-center flex flex-col items-center space-y-6">

        {/* Logo / Brand */}
        <h1 className="text-3xl font-extrabold tracking-wider">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-cyan-400">
            MyBrand
          </span>
        </h1>

        {/* Navigation Links */}
        <div className="flex space-x-8 font-medium text-gray-400">
          <Link to="/" className="hover:text-blue-400 transition">Home</Link>
          <Link to="/about" className="hover:text-blue-400 transition">About</Link>
          <Link to="/menu" className="hover:text-blue-400 transition">Menu</Link>
          <Link to="/docs" className="hover:text-blue-400 transition">Docs</Link>
          <Link to="/login" className="hover:text-blue-400 transition">Login</Link>
        </div>

        {/* Divider */}
        <div className="w-24 h-[1px] bg-gradient-to-r from-transparent via-blue-500 to-transparent my-4"></div>

        {/* Social Icons */}
        <div className="flex space-x-5">
          <a href="#" className="hover:text-blue-400 transition">
            <i className="fab fa-facebook-f"></i>
          </a>
          <a href="#" className="hover:text-blue-400 transition">
            <i className="fab fa-twitter"></i>
          </a>
          <a href="#" className="hover:text-blue-400 transition">
            <i className="fab fa-github"></i>
          </a>
          <a href="#" className="hover:text-blue-400 transition">
            <i className="fab fa-linkedin"></i>
          </a>
        </div>

        {/* Copyright */}
        <p className="text-sm text-gray-500 mt-4">
          © {new Date().getFullYear()} MyBrand. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
