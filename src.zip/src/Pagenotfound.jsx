import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-gray-900 via-gray-950 to-black text-white text-center px-6">
      {/* Glowing 404 */}
      <h1 className="text-[10rem] sm:text-[14rem] font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-cyan-400 drop-shadow-lg animate-pulse">
        404
      </h1>

      {/* Message */}
      <h2 className="text-3xl sm:text-4xl font-semibold mb-4">
        Oops! Page Not Found 😕
      </h2>
      <p className="text-gray-400 max-w-md mb-10">
        The page you’re looking for doesn’t exist or may have been moved.
      </p>

      {/* Illustration */}
      <img
        src="https://illustrations.popsy.co/blue/lost.svg"
        alt="Page not found"
        className="w-80 h-auto mb-10 opacity-90 hover:opacity-100 transition"
      />

      {/* Button */}
      <Link
        to="/"
        className="relative px-8 py-3 rounded-full font-semibold bg-gradient-to-r from-blue-600 to-cyan-500 hover:scale-105 transition-transform shadow-lg"
      >
        Go Home 🏠
        <span className="absolute inset-0 bg-gradient-to-r from-blue-500 to-cyan-400 blur-md opacity-50 rounded-full -z-10"></span>
      </Link>
    </div>
  );
}
